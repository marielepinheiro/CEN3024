public class Recursion {

	//main
	
  public static void main(String[] args) {
    long numbersSum = numbersSum(9);
    System.out.println(numbersSum);
  }

 
  public static long numbersSum(long number) {
  
    if (number != 0) {
      return number + numbersSum(number - 1);
    } else {
      return number;
    }
  }
}