
public class TextReader {

}
