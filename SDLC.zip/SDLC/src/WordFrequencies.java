import java.io.*;

public class WordFrequencies {
    
      static WordData[] words;  // An array to hold the words from the file.
                                //   Note that the array will be expanded as 
                                //   necessary, in the insertWord() subroutine.
       
      static int wordCount;   // The number of words currently stored in
                              //   the array.
    
    
      public static void main(String[] args) {
       
         TextReader in;    // A stream for reading from the input file.
         PrintWriter out;  // A stream for writing to the output file.
          
         String inputFileName;   // Input file name, specified by the user.
         String outputFileName;  // Output file name, specified by the user.
          
         words = new WordData[10];  // Start with space for 10 words.
         wordCount = 0;             // Currently, there are no words in the array.
          
         /* Get the input file name from the user and try to create the
            input stream.  If there is a FileNotFoundException, print
            a message and terminate the program. */
          
         TextIO.put("Input file name?  ");
         inputFileName = TextIO.getln().trim();
         try {
            in = new TextReader(new FileReader(inputFileName));
         }
         catch (FileNotFoundException e) {
             TextIO.putln("Can't find file \"" + inputFileName + "\".");
             return;
         }
         
    
         TextIO.put("Output file name? ");
         outputFileName = TextIO.getln().trim();
         try {
            out = new PrintWriter(new FileWriter(outputFileName));
         }
         catch (IOException e) {
             TextIO.putln("Can't open file \"" + outputFileName + "\" for output.");
             TextIO.putln(e.toString());
             return;
         }
          
         try {
            while (true) {
                  // Skip past and non-letters in the input stream.  If an
                  //   end-of-stream has been reached, end the loop.  Otherwise,
                  //   read a word and insert it into the array of words.
               while ( ! in.eof() && ! Character.isLetter(in.peek()) )
                  in.getAnyChar();
               if (in.eof())
                  break;
               insertWord(in.getAlpha());
            }
         }
         catch (TextReader.Error e) {
            TextIO.putln("An error occurred while reading from the input file.");
            TextIO.putln(e.toString());
            return;
         }
          
         /* Output the words in alphabetical order. */
          
         out.println("Words in alphabetical order, with the number of occurrences:");
         out.println("-----------------------------------------------------------");
         out.println();
          
         putWordList(out);
          
         /* Sort the list of words according the frequency with which
            they were found in the file, and then output the list again. */
          
         sortByFrequency();
          
         out.println();
         out.println();
         out.println("Words in order of frequency:");
         out.println("---------------------------");
         out.println();
          
         putWordList(out);
          
         if (out.checkError()) {
            TextIO.putln("Some error occurred while writing to the output file.");
            TextIO.putln("The output might be missing, incomplete, or corrupted.");
         }
         else {
            TextIO.putln("Done.");
         }
       
      } 
      
      static void insertWord(String w) {
          
         int pos = 0;  
         w = w.toLowerCase();
          
         while (pos < wordCount && words[pos].word.compareTo(w) < 0)
            pos++;
         if (pos < wordCount && words[pos].word.equals(w)) {
            words[pos].count++;
            return;
         }

    
         if (wordCount == words.length) {
            WordData[] newWords = new WordData[words.length*2];
            System.arraycopy(words,0,newWords,0,wordCount);
            words = newWords;
         }
          
    
    
         for (int i = wordCount; i > pos; i--)
            words[i] = words[i-1];
         words[pos] = new WordData(w);
         wordCount++;
    
      }  // end insertWord()
       
       
      static void putWordList(PrintWriter output) {
     
          for (int i = 0; i < wordCount; i++) {
             output.print("   ");
             output.print(words[i].word);
             for (int space = words[i].word.length(); space < 15; space++)
                output.print(" ");
             output.print(" ");
             output.println(words[i].count);
          }
      }  
       
      static void sortByFrequency() {
     
          for (int i = 1; i < wordCount; i++) {
             WordData temp = words[i];  // Save the word in position i.
             int location;              // An index in the array.
             location = i - 1;
             while (location >= 0 && words[location].count < temp.count) {
                   // Bump words that have frequencies less than the frequency
                   // of temp up one space in the array.
                words[location + 1] = words[location]; 
                location--;
             }
             words[location + 1] = temp;  // Put temp in last vacated space.
           
          }
      }  